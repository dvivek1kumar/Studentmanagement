package com.Vivek.Service;

import java.util.List;

import com.Vivek.Entity.Student;

public interface StudentService {
	
	Student createStudent(Student st);
// after creating student in database it will return student object
	List<Student>getStudents();
	Student getStudentById(int id);

}
