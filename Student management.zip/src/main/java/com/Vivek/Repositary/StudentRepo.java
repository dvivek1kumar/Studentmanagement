package com.Vivek.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Vivek.Entity.Student;

public interface StudentRepo extends  JpaRepository<Student,Integer>{

}
