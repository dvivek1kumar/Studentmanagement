package com.Vivek.Controller;

public @interface getStudent {

	String value();

}
