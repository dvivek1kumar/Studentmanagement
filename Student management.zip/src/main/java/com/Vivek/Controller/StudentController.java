package com.Vivek.Controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.Vivek.Entity.Student;
import com.Vivek.Service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	StudentService ser;
	
	@PostMapping("/api/createStudent")
	Student createStudent(@RequestBody Student st)
	//@RequestBody  convert the jason to object and store it in a database
	{
		return ser.createStudent(st);
		
	}
	@GetMapping("/getStudent")
	public List<Student> getStudents() {
		// TODO Auto-generated method stub
		return ser.getStudents();
	
	}
	@GetMapping("/api/grtStuentById/{id}")
	 public Student getStudentById(int id) {
		return ser.getStudentById(id);
		
	}
}
