//package com.Vivek.ServiceImplementation;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.Vivek.Entity.Student;
//import com.Vivek.Repositary.StudentRepo;
//import com.Vivek.Service.StudentService;
//
//
//@Service// enternally we need to tell springboot when any service layer method wllbe called,service impl class will act as a service
//public class StudentServiceImpm implements StudentService{
//	@Autowired
//	StudentRepo r;//by using student object store data in database
//	
//	
//	@Override
//	public Student createStudent(Student st)
//	{
//		return r.save(st);
//		
//	}
//
//
//	@Override
//	public List<Student> getStudents() {
//		// TODO Auto-generated method stub
//		return r.findAll();
//		
//	}
//	@Override
//	public Student getStudentById(int id) {
//		
//		Student s=r.findById(id).get();
//		return r.findById(id).get();
//		
//	}
//	@Override
//	public Student updateStudentById(int id,Student s) {
//		Student a=r.findById(id).get();
//		a.setName(s.getName());
//		s.setPhone_no(s.getPhone_no());
//		s.setAddress(s.getAddress());
//	}
//
//}
package com.Vivek.ServiceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Vivek.Entity.Student;
import com.Vivek.Repositary.StudentRepo;
import com.Vivek.Service.StudentService;

@Service
public class StudentServiceImpm implements StudentService {

    @Autowired
    StudentRepo r;

    @Override
    public Student createStudent(Student st) {
        return r.save(st);
    }

    @Override
    public List<Student> getStudents() {
        return r.findAll();
    }

    @Override
    public Student getStudentById(int id) {
        return r.findById(id).orElse(null);
    }

    public Student updateStudentById(int id, Student s) {
        Student existingStudent = r.findById(id).orElse(null);
        if (existingStudent != null) {
            existingStudent.setName(s.getName());
            existingStudent.setPhone_no(s.getPhone_no());
            existingStudent.setAddress(s.getAddress());
            return r.save(existingStudent);
        }
        return null; // or throw an exception for not found
    }
}

